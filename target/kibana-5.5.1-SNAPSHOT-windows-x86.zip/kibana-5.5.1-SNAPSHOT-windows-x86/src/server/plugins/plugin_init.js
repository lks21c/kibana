'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _lodash = require('lodash');

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { return Promise.resolve(value).then(function (value) { step("next", value); }, function (err) { step("throw", err); }); } } return step("next"); }); }; }

exports.default = (() => {
  var _ref = _asyncToGenerator(function* (plugins) {
    const path = [];

    const initialize = (() => {
      var _ref2 = _asyncToGenerator(function* (id, fn) {
        const plugin = plugins.byId[id];

        if ((0, _lodash.includes)(path, id)) {
          throw new Error(`circular dependencies found: "${path.concat(id).join(' -> ')}"`);
        }

        path.push(id);

        for (const reqId of plugin.requiredIds) {
          if (!plugins.byId[reqId]) {
            throw new Error(`Unmet requirement "${reqId}" for plugin "${id}"`);
          }

          yield initialize(reqId, fn);
        }

        yield plugin[fn]();
        path.pop();
      });

      return function initialize(_x2, _x3) {
        return _ref2.apply(this, arguments);
      };
    })();

    const collection = plugins.toArray();
    for (const _ref3 of collection) {
      const { id } = _ref3;

      yield initialize(id, 'preInit');
    }

    for (const _ref4 of collection) {
      const { id } = _ref4;

      yield initialize(id, 'init');
    }
  });

  return function (_x) {
    return _ref.apply(this, arguments);
  };
})();

module.exports = exports['default'];

'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mixin = require('./mixin');

Object.defineProperty(exports, 'indexPatternsMixin', {
  enumerable: true,
  get: function () {
    return _mixin.indexPatternsMixin;
  }
});

'use strict';

// this file is not transpiled in dev
require('./options').registerNodeOptions();
require('./polyfills');

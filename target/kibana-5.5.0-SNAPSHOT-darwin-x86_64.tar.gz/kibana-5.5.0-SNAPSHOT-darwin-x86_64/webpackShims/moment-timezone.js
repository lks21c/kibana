'use strict';

var moment = module.exports = require('../node_modules/moment-timezone/moment-timezone');
moment.tz.load(require('../node_modules/moment-timezone/data/packed/latest.json'));
